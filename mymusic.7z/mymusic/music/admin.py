from django.contrib import admin
from .models import Artist, RecordLabel, Album

admin.site.register(Artist)
admin.site.register(RecordLabel)
admin.site.register(Album)