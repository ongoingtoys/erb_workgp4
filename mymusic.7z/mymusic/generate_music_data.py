import os
import random
from faker import Faker

# 設置 Django 環境變量
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'mymusic.settings')
import django
django.setup()

from music.models import Artist, RecordLabel, Album

fake = Faker()

# 生成10位藝術家
artists = [Artist(name=fake.name(), birth_date=fake.date_of_birth()) for _ in range(10)]
Artist.objects.bulk_create(artists)

# 生成5家唱片公司
record_labels = [RecordLabel(name=fake.company(), address=fake.address()) for _ in range(5)]
RecordLabel.objects.bulk_create(record_labels)

# 生成20張專輯
albums = []
genres = ["Pop", "Rock", "Jazz", "Classical", "Hip-Hop", "Electronic", "Country"]
for _ in range(20):
    album = Album(
        title=fake.catch_phrase(),
        artist=random.choice(Artist.objects.all()),
        record_label=random.choice(RecordLabel.objects.all()),
        release_date=fake.date_between(start_date='-30y', end_date='today'),
        genre=random.choice(genres)
    )
    albums.append(album)
Album.objects.bulk_create(albums)

print("音樂資料生成完成！")